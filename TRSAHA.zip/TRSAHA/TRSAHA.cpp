#include "stdio.h"
#include "stdlib.h"
#include "time.h"
#include "math.h"
#include "string.h"
#include <float.h>

#define rdint(i) (rand() % (int)(i))
#define rdft() ((float)rdint(7384)) / 7383.0
#define rnd(a, b) (rdint((int)(b) - (int)(a) + 1) + (int)(a))
#define MAXARR 100 //LN
#define POPSIZE 40
#define DIMENSION 100
#define MAXITERA 5000
#define GERI 10
#define MX 2
float Pd = 0.03,Cp = 0.1,Lp=0.1,alpha = 0.1;
char filename1[] = "test/data/1qkpcg1.txt";
char filename2[] = "test/bf/1qkpcg1_bfitness.txt";
char filename3[] = "test/record/1qkpcg1_rec.txt";

struct indi
{
    int bix[DIMENSION];
    int conflict[DIMENSION];
    float fitx, Weight;

} individual[POPSIZE + 1], BEST,WORST,indiBest[POPSIZE];

float density=0,BESTV = 0,WORSTV = 1000000,Mean = 0.0,KNAPSIZE = 0.0;
float Opt = 0.0, alltime = 0.0, Std = 0.0,usetime;
float arybest[GERI],record[GERI + 1];
float Cvalue[DIMENSION],Wvalue[DIMENSION],quad_profit[DIMENSION][DIMENSION] ,deltaArr[DIMENSION];
int indexDen[DIMENSION], indexEdg[DIMENSION], indexHy[DIMENSION];
int num_Edge = 0,hit = 0;
int Edge[DIMENSION][DIMENSION],degree[DIMENSION];
time_t first, second;
FILE *fp1, *fp2, *fp3;

void loadfile(void);
void storefile(void);
void calculateindex(void);
void initialize(void);
void evolution(void);
void calculate_Conflict(int num);
void mutatefunction(int num); //OWM
void TwoPhaseRepaireOptimizationwithProbability1(int num); //TSSRO
void getdeltaMatrix(int num);
int swapOptimizaiton2(int num);//LNS
int addOptimizaiton2(int num);//LNA
int AddFeasible(int num, int in);
int SwapFeasible(int num, int out, int in);
void LSO2(int num);  //LSO

main()
{
    int i,m;
    int t = 0, generation;
    for (i = 0; i < DIMENSION; i++)
    {
        degree[i] = 0;
        for (m = 0; m < DIMENSION; m++)
        {
            quad_profit[i][m] = 0;
            Edge[i][m] = 0;
        }
    }
    for (i = 0; i <= GERI; i++)
        record[i] = 0;
    loadfile();
    t = 0;

    while (t < GERI)
    {
        srand(time(NULL));
        first = clock();
        calculateindex();
        initialize();
        generation = 0;
        while (generation < MAXITERA)
        {

            evolution();
            if (generation % (MAXITERA / GERI) == 0)
                record[generation / (MAXITERA / GERI)] += BEST.fitx;
            else if (generation + 1 == MAXITERA)
                record[GERI] += BEST.fitx;
            generation++;
        }

        alltime += usetime;
        if (BEST.fitx == Opt)
            hit++;
        arybest[t] = BEST.fitx;
        Mean += BEST.fitx;
        if (BEST.fitx > BESTV)
        {
            BESTV = BEST.fitx;
        }
        if (BEST.fitx < WORSTV)
        {
            WORSTV = BEST.fitx;
        }
        t++;
        printf("%d, ", t);
        printf("BESTfitness : %.2f  Time:%.2f \n", BEST.fitx, usetime);
    }
    storefile();
    exit(0);
}
void calculateindex(void)
{
    int i, j, pos1, pos2, pos3, temp1;
    float rateDen[DIMENSION], rateEdg[DIMENSION], rateHy[DIMENSION], temp2 = alpha * density;
    for (i = 0; i < DIMENSION; i++)
    {

        rateHy[i] = Cvalue[i];
        for (j = i + 1; j < DIMENSION; j++)
        {
            if (Edge[i][j] == 0)
                rateHy[i] += quad_profit[i][j];
        }
        rateDen[i] = 1 / (Wvalue[i]);
        indexDen[i] = i;
        rateEdg[i] = 1 / (degree[i] + FLT_EPSILON);
        indexEdg[i] = i;
        rateHy[i] = rateHy[i] / (temp2 * degree[i] + Wvalue[i]);
        indexHy[i] = i;
    }
    for (i = 0; i < DIMENSION - 1; i++)
    {
        pos1 = i;
        pos2 = i;
        pos3 = i;
        for (j = i; j < DIMENSION; j++)
        {
            if (rateDen[pos1] < rateDen[j])
                pos1 = j;
            if (rateEdg[pos2] < rateEdg[j])
                pos2 = j;
            if (rateHy[pos3] < rateHy[j])
                pos3 = j;
        }
        temp2 = rateDen[i];
        rateDen[i] = rateDen[pos1];
        rateDen[pos1] = temp2;
        temp1 = indexDen[pos1];
        indexDen[pos1] = indexDen[i];
        indexDen[i] = temp1;

        temp2 = rateEdg[i];
        rateEdg[i] = rateEdg[pos2];
        rateEdg[pos2] = temp2;
        temp1 = indexEdg[pos2];
        indexEdg[pos2] = indexEdg[i];
        indexEdg[i] = temp1;

        temp2 = rateHy[i];
        rateHy[i] = rateHy[pos3];
        rateHy[pos3] = temp2;
        temp1 = indexHy[pos3];
        indexHy[pos3] = indexHy[i];
        indexHy[i] = temp1;
    }
}
void initialize()
{
    int i, j;
    BEST.fitx = 0;
    for (i = 0; i < POPSIZE; i++)
    {
        for (j = 0; j < DIMENSION; j++)
        {
            individual[i].bix[j] = rdint(MX);
            individual[i].conflict[j] = 0;
        }
        mutatefunction(i);
        calculate_Conflict(i);
        TwoPhaseRepaireOptimizationwithProbability1(i);
        indiBest[i] = individual[i];
        if(individual[i].fitx>BEST.fitx){
            usetime = (1.0 * clock() - first) / CLOCKS_PER_SEC;
            BEST = individual[i];
        }

    }

}

void TwoPhaseRepaireOptimizationwithProbability1(int num)
{
    int i, j, sum_conflict = 0, flag;
    float Weight = 0;
    for (i = 0; i < DIMENSION; i++)
    {
        Weight += individual[num].bix[i] * Wvalue[i];
        sum_conflict += individual[num].conflict[i];
    }
    i = DIMENSION - 1;
    while (sum_conflict > 0)
    {
        if (individual[num].conflict[indexEdg[i]] != 0 && individual[num].bix[indexEdg[i]] == 1 && rdft() < 0.5)
        {
            individual[num].bix[indexEdg[i]] = 0;
            Weight -= Wvalue[indexEdg[i]];
            sum_conflict -= individual[num].conflict[indexEdg[i]];
            individual[num].conflict[indexEdg[i]] = 0;
            for (j = 0; j < DIMENSION; j++)
            {
                if (j != indexEdg[i] && Edge[indexEdg[i]][j] == 1 && individual[num].bix[j] == 1)
                {
                    individual[num].conflict[j] -= 1;
                    sum_conflict -= 1;
                }
            }
        }
        i--;
        if (i < 0)
            i = DIMENSION - 1;
    }
    i = DIMENSION - 1;
    while (Weight > KNAPSIZE)
    {
        if (individual[num].bix[indexDen[i]] == 1 && rdft() < 0.5)
        {
            individual[num].bix[indexDen[i]] = 0;
            Weight -= Wvalue[indexDen[i]];
        }
        i--;
        if (i < 0)
            i = DIMENSION - 1;
    }

    for (i = 0; i < DIMENSION; i++)
    {
        flag = 0;
        if (individual[num].bix[indexHy[i]] == 0 && Weight + Wvalue[indexHy[i]] <= KNAPSIZE)
        {
            for (j = 0; j < DIMENSION; j++)
            {
                if (j != indexHy[i] && individual[num].bix[j] == 1 && Edge[indexHy[i]][j] == 1)
                {
                    flag = 1;
                    break;
                }
            }
            if (!flag)
            {
                Weight += Wvalue[indexHy[i]];
                individual[num].bix[indexHy[i]] = 1;
            }
        }
    }
    individual[num].fitx = 0;
    individual[num].Weight = Weight;
    for (i = 0; i < DIMENSION; i++)
    {
        if (individual[num].bix[i] != 0)
        {
            individual[num].fitx += individual[num].bix[i] * Cvalue[i];
            for (j = i + 1; j < DIMENSION; j++)
                individual[num].fitx += individual[num].bix[i] * individual[num].bix[j] * quad_profit[i][j];
        }
    }
}


void calculate_Conflict(int num)
{
    int j, j1;
    for (j = 0; j < DIMENSION; j++)
    {
        if (individual[num].bix[j] == 1)
        {
            for (j1 = j + 1; j1 < DIMENSION; j1++)
            {
                if (individual[num].bix[j1] == 1 && Edge[j][j1] == 1)
                {
                    individual[num].conflict[j]++;
                    individual[num].conflict[j1]++;
                }
            }
        }
    }
}

void evolution(void)
{
    int i,j;
    int p1, p2;

    for (i = 0; i < POPSIZE; i++)
    {

        p1 = rdint(POPSIZE);
        while (p1 == i)
            p1 = rdint(POPSIZE);
        p2 = rdint(POPSIZE);
        while ((p2 == i) || (p2 == p1))
            p2 = rdint(POPSIZE);
        for (j = 0; j < DIMENSION; j++)
        {
            if (rdft() < Cp) //ISDO
                individual[POPSIZE].bix[j] = individual[i].bix[j] ^ (individual[p1].bix[j] ^ individual[p2].bix[j]);
            else
                individual[POPSIZE].bix[j] = individual[i].bix[j];
        }
        mutatefunction(POPSIZE);
        calculate_Conflict(POPSIZE);
        TwoPhaseRepaireOptimizationwithProbability1(POPSIZE);
        if (rdft() < Lp)
        {
            LSO2(POPSIZE);
        }

        if (individual[POPSIZE].fitx > individual[i].fitx)
        {
            individual[i] = individual[POPSIZE];
            indiBest[i] = individual[POPSIZE];
            if (individual[i].fitx > BEST.fitx){
                usetime = (1.0 * clock() - first) / CLOCKS_PER_SEC;
                BEST = individual[i];
            }
        }
        else
        {
            individual[i] = indiBest[i];
        }
    }
}



void mutatefunction(int num)
{
    int j;
    int x, d;
    for (j = 0; j < DIMENSION; j++)
    {

        if (individual[num].bix[j] == 0 && rdft() < Pd)
            individual[num].bix[j] = 1;
    }
}
void loadfile()
{
    int i = 0, j = 0, i1 = 0, i2 = 0, dim;
    float q_profit = 0;
    if ((fp1 = fopen(filename1, "r")) == NULL)
    {
        printf("ERROR");
    }
    fscanf(fp1, "%f%d%d%f", &Opt, &dim, &num_Edge, &KNAPSIZE);
    density = (float)num_Edge / ((dim * (dim - 1)));
    printf("density:%lf \n", density);
    for (i = 0; i < DIMENSION; i++)
    {
        fscanf(fp1, "%f", &Cvalue[i]);
    }
    for (i = 0; i < DIMENSION; i++)
    {
        fscanf(fp1, "%f", &Wvalue[i]);
    }
    for (i = 0; i < DIMENSION; i++)
    {
        quad_profit[i][i] = 0;
        for (j = i + 1; j < DIMENSION; j++)
        {
            fscanf(fp1, "%f", &q_profit);
            quad_profit[i][j] = q_profit;
            quad_profit[j][i] = q_profit;
        }
    }

    for (i = 0; i < num_Edge; i++)
    {
        fscanf(fp1, "%d%d", &i1, &i2);
        Edge[i1 - 1][i2 - 1] = 1;
        Edge[i2 - 1][i1 - 1] = 1;
        degree[i1 - 1]++;
        degree[i2 - 1]++;
    }

    fclose(fp1);
}
void storefile()
{
    int i = 0;
    float avgTime = 0.0;
    if ((fp1 = fopen(filename2, "a")) == NULL)
    {
        printf("ERROR");
        exit(0);
    }
    if ((fp2 = fopen(filename3, "a")) == NULL)
    {
        printf("ERROR");
        exit(0);
    }
    for (i = 0; i <= GERI; i++)
    {
        record[i] = record[i] / GERI;
        fprintf(fp2, "%f\n", record[i]);
    }
    Mean = Mean / GERI;
    avgTime = alltime / GERI;
    float temp = 0.0;
    for (i = 0; i < GERI; i++)
        temp += (Mean - arybest[i]) * (Mean - arybest[i]);
    Std = sqrt(temp / GERI);
    fprintf(fp1, "Opt:%.0f ", Opt);
    fprintf(fp1, "Best:%.0f ", BESTV);
    fprintf(fp1, "Mean:%.2f ", Mean);
    fprintf(fp1, "Worst:%.0f ", WORSTV);
    fprintf(fp1, "Std:%.4f ", Std);
    fprintf(fp1, "hit:%d ", hit);
    fprintf(fp1, "avgTime:%.4f \n", avgTime);

    fclose(fp1);
    fclose(fp2);
}
void getdeltaMatrix(int num)
{
    int i, j;
    for (i = 0; i < DIMENSION; i++)
    {
        deltaArr[i] = 0;
        for (j = 0; j < DIMENSION; j++)
        {
            if (individual[num].bix[j] && i != j)
            {
                deltaArr[i] += quad_profit[i][j];
            }
        }
    }
}
void add_phase(int num)
{
    int i, j, flag, mIndex, improve = 0;
    float deltaMax = -9999999;
    for (i = 0; i < DIMENSION; i++)
    {
        if (individual[num].bix[i] == 0 && individual[num].Weight + Wvalue[i] < KNAPSIZE)
        {
            flag = 0;
            for (j = 0; j < DIMENSION; j++)
            {
                if (j != i && individual[num].bix[j] && Edge[i][j])
                {
                    flag = 1;
                    break;
                }
            }
        }
        if (!flag && deltaMax < Cvalue[i] + deltaArr[i])
        {
            deltaMax = Cvalue[i] + deltaArr[i];
            mIndex = i;
            improve = 1;
        }
    }

    if (improve)
    {
        individual[num].bix[mIndex] = 1;
        individual[num].Weight += Wvalue[mIndex];
        individual[num].fitx += deltaMax;
    }
}
int SwapFeasible(int num, int out, int in)
{

    int flag = 1, i;
    if (individual[num].Weight + Wvalue[in] - Wvalue[out] > KNAPSIZE)
        flag = 0;
    else
    {
        for (i = 0; i < DIMENSION; i++)
        {
            if (individual[num].bix[i] == 1 && Edge[in][i] == 1 && i != out && i != in)
            {
                flag = 0;
                break;
            }
        }
    }

    return flag;
}


int swapOptimizaiton2(int num)
{

    int i, j, flag, mIndex;
    float deltaMax = 0, delta;
    int itemsIn[MAXARR], itemsOut[MAXARR], swapLen = 0, itemIn, itemOut, itemMaxIn, itemMaxOut;

        flag = 0;
        swapLen = 0;
        deltaMax = 0;
        for (i = 0; i < DIMENSION; i++)
        {
            if (individual[num].bix[i])
            {
                for (j = 0; j < DIMENSION; j++)
                {
                    if (individual[num].bix[j] == 0 && i != j && SwapFeasible(num, i, j))
                    {
                        delta = Cvalue[j] - Cvalue[i] + deltaArr[j] - deltaArr[i] - quad_profit[i][j];
                        if (delta > deltaMax)
                        {
                            deltaMax = delta;
                            swapLen = 0;
                            itemsIn[swapLen] = j;
                            itemsOut[swapLen] = i;
                            swapLen++;
                        }
                        else if (delta == deltaMax && swapLen < MAXARR)
                        {
                            itemsIn[swapLen] = j;
                            itemsOut[swapLen] = i;
                            swapLen++;
                        }
                    }
                }
            }
        }

        if (swapLen > 0 && deltaMax > 0)
        {
            mIndex = rand() % swapLen;
            itemIn = itemsIn[mIndex];
            itemOut = itemsOut[mIndex];

            flag = 1;
        }
        if (flag)
        {
            individual[num].bix[itemIn] = 1;
            individual[num].bix[itemOut] = 0;
            individual[num].Weight += Wvalue[itemIn] - Wvalue[itemOut];
            for (i = 0; i < DIMENSION; i++)
            {
                deltaArr[i] -= quad_profit[i][itemOut];
                deltaArr[i] += quad_profit[i][itemIn];
            }
            individual[num].fitx += deltaMax;
            if (individual[num].fitx > BEST.fitx)
            {
                usetime = (1.0 * clock() - first) / CLOCKS_PER_SEC;
                BEST = individual[num];
            }
        }
    return flag;
}


int AddFeasible(int num, int in)
{

    int flag = 1, i;
    if (individual[num].Weight + Wvalue[in]> KNAPSIZE)
        flag = 0;
    else
    {
        for (i = 0; i < DIMENSION; i++)
        {
            if (individual[num].bix[i] == 1 && Edge[in][i] == 1 && i != in)
            {
                flag = 0;
                break;
            }
        }
    }

    return flag;
}

int addOptimizaiton2(int num)
{

    int i, j, flag, mIndex;
    float deltaMax = 0, delta;
    int itemsIn[MAXARR], addLen = 0, itemIn;
        flag = 0;
        addLen = 0;
        deltaMax = 0;
        for (i = 0; i < DIMENSION; i++)
        {
            if (individual[num].bix[i]==0 && AddFeasible(num, i))
            {

                delta = Cvalue[i]+deltaArr[i];
                if(delta>deltaMax){
                    deltaMax = delta;
                    addLen = 0;
                    itemsIn[addLen++] = i;
                }
                else if(delta==deltaMax&& addLen< MAXARR){
                    itemsIn[addLen++] = i;

                }
            }
        }

        if (addLen > 0 && deltaMax > 0)
        {
            mIndex = rand() % addLen;
            itemIn = itemsIn[mIndex];
            flag = 1;
        }
        if (flag)
        {
            individual[num].bix[itemIn] = 1;
            individual[num].Weight += Wvalue[itemIn];
            for (i = 0; i < DIMENSION; i++)
            {
                deltaArr[i] += quad_profit[i][itemIn];
            }
            individual[num].fitx += deltaMax;
            if (individual[num].fitx > BEST.fitx)
            {
                usetime = (1.0 * clock() - first) / CLOCKS_PER_SEC;
                BEST = individual[num];
            }

        }
     return flag;
}


void LSO2(int num){

    int flag1 = 1,flag2 = 1;
    getdeltaMatrix(num);
    while(flag1||flag2){
        flag1 = swapOptimizaiton2(num);
        flag2 = addOptimizaiton2(num);

    }



}



